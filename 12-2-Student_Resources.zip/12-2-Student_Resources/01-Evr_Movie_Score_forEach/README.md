# Movie Scores with forEach

## Instructions

* Revisit the [MovieScore](Unsolved/index.js) activity from the previous class.

* Refactor the code to use the `forEach` method instead of a `for loop`.

* **Hint:** Remember that `forEach` will pass a function to each element in an array.
